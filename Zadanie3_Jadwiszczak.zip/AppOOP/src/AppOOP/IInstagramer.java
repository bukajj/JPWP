package AppOOP;

public interface IInstagramer {

    void LiczbaObserwujacych();
}
