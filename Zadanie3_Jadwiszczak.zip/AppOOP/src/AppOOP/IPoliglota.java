package AppOOP;

public interface IPoliglota {
    void znaneJezyki();
}
